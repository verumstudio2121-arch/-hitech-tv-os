package com.hitech.tvos

import android.content.Context
import android.content.Intent

/** Blocking – call from a background thread only. */
object AppRepository {

    // Streaming apps are pinned to the front of the dock, in this order.
    private val PRIORITY = listOf(
        listOf("com.google.android.youtube.tv", "com.google.android.youtube"),
        listOf("com.netflix.ninja", "com.netflix.mediaclient"),
        listOf("in.startv.hotstar.dplus.tv", "in.startv.hotstar.dplus", "in.startv.hotstar"),
        listOf("com.amazon.amazonvideo.livingroom", "com.amazon.avod"),
        listOf("com.sonyliv"),
        listOf("com.google.android.youtube.tvmusic", "com.google.android.apps.youtube.music")
    )

    private fun rank(pkg: String): Int {
        val i = PRIORITY.indexOfFirst { pkg in it }
        return if (i == -1) Int.MAX_VALUE else i
    }

    fun load(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()

        for (category in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName || !seen.add(pkg)) continue
                val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg) ?: continue
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                val banner = ri.activityInfo.loadBanner(pm)
                out += AppEntry(
                    packageName = pkg,
                    label = ri.loadLabel(pm).toString(),
                    banner = banner ?: ri.loadIcon(pm),
                    hasBanner = banner != null,
                    launchIntent = launch
                )
            }
        }
        return out.sortedWith(compareBy<AppEntry>({ rank(it.packageName) }, { it.label.lowercase() }))
    }
}
