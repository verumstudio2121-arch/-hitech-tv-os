package com.hitech.tvos

/** Edit these for your household. */
object Config {
    const val OWNER_NAMES = "Mukesh & Vaishali"
    const val CITY = "Virar"
    const val LATITUDE = 19.4559
    const val LONGITUDE = 72.8115
    const val WEATHER_REFRESH_MS = 30 * 60 * 1000L
}
