package com.hitech.tvos

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.hitech.tvos.databinding.ItemAppBinding

class AppAdapter(private val onLaunch: (AppEntry) -> Unit) :
    RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppEntry> = emptyList()

    init { setHasStableIds(true) }

    class VH(val b: ItemAppBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(new: List<AppEntry>) {
        val old = items
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = new.size
            override fun areItemsTheSame(o: Int, n: Int) = old[o].packageName == new[n].packageName
            override fun areContentsTheSame(o: Int, n: Int) = old[o].label == new[n].label
        })
        items = new
        diff.dispatchUpdatesTo(this)
    }

    override fun getItemId(position: Int) = items[position].packageName.hashCode().toLong()
    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        val vh = VH(b)
        b.root.setOnClickListener { items.getOrNull(vh.adapterPosition)?.let(onLaunch) }
        b.root.onFocusChangeListener = View.OnFocusChangeListener { v, focused ->
            // 1.08x elevation; the cyan glow stroke comes from the bg_card selector.
            v.animate().cancel()
            v.animate()
                .scaleX(if (focused) 1.08f else 1f)
                .scaleY(if (focused) 1.08f else 1f)
                .translationZ(if (focused) 12f else 0f)
                .setDuration(140)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
        return vh
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val e = items[position]
        h.b.banner.setImageDrawable(e.banner)
        // Icon-only apps get their name underneath; banners already carry it.
        h.b.label.visibility = if (e.hasBanner) View.GONE else View.VISIBLE
        h.b.label.text = e.label
        val p = (10 * h.b.root.resources.displayMetrics.density).toInt()
        h.b.banner.setPadding(p, p, p, if (e.hasBanner) p else p * 3)
    }
}
