package com.hitech.tvos

import android.app.ActivityManager
import android.content.Context
import android.os.Environment
import android.os.StatFs

object SystemStats {
    /** "Memory used / total MB · Storage N GB free". One-shot reads, no polling. */
    fun summary(ctx: Context): String {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val totalMb = mi.totalMem / MB
        val usedMb = (mi.totalMem - mi.availMem) / MB
        val freeGb = StatFs(Environment.getDataDirectory().path).availableBytes / GB
        return "Memory $usedMb / $totalMb MB  ·  Storage $freeGb GB free"
    }
    private const val MB = 1024L * 1024L
    private const val GB = 1024L * 1024L * 1024L
}
